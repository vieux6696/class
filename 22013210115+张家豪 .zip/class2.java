package Chapter2;

import java.util.Scanner;

pubilc class class2{

    public static void main(String[] args) {

    double income = 0.0  //定义可征税收入

       int status = 0;  //定义纳税人情况

       double tax = 0 ; //定义税额

//提示用户输入纳税人类型

System.out println("请输入可征税收入")；

Scanner inStatus = new Scanner (System.in);

if(in Status.hasNextInt()){

status = inStatus.nexInt();}    //输入纳税人类型

System .out.println("请输入可征税收入")；

Scanner in = new Scanner(System.in);

if (in.hasNextDouble()){

income = in.nextDouble();}

if (status = = 0)  {  //计算单身纳税人的缴纳税额


        if (status == 0) {
            if (income <= 6000) {
                tax = income * 0.10;
            } else if (income <= 27950) {
                tax = 6000 * 0.10 + (income - 6000) * 0.15;
            } else if (income <= 67700) {
                tax = 6000 * 0.10 + (27950 - 6000) * 0.15 + (income - 27950) * 0.27;
            } else {
                tax = 6000 * 0.10 + (27950 - 6000) * 0.15 + (67700 - 27950) * 0.27 + (income - 67700) * 0.30;
            }
        } else if (status == 1) {
            // 处理已婚纳税人的税金计算
            // ...
        } else if (status == 2) {
            // 处理家庭纳税人的税金计算
            // ...
        } else {
            System.out.println("无效的纳税人情况");
        }

       System.out.println("纳税人需要缴纳的税额为“+tax+”人民币")
    }
}
